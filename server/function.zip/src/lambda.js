import serverless from 'serverless-http';
import app from './app.js';
const wrapped=serverless(app);

const handler=async(event,context)=>{
    context.callbackwithwaitsforemptyeventloop=false;
    return wrapped(event,context);
}